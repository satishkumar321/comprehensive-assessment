package uistore;

import org.openqa.selenium.By;

public class ContactUsPageUI {
	public static By contactus = By.xpath(".//*[@href='/contact-us']");
	public static By phoneno = By.xpath(".//*[@href='tel:90 4545 0000']");
}
