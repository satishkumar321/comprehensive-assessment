package uistore;

import org.openqa.selenium.By;

public class OneWayPageUI {
	
	public static By oneway = By.xpath(".//*[@href='/one-way-cabs']");
	public static By agra = By.xpath(".//*[@id='tabAgra']");
	public static By place = By.xpath(".//*[@href='/agra/agra-to-shikohabad-one-way-cabs']");		
}
	