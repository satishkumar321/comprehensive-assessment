package uistore;

import org.openqa.selenium.By;

public class AboutUsPageUI {
	public static By aboutus = By.xpath(".//*[@href='/aboutus']");
	public static By ceo = By.xpath(".//*[@class='ceoName']");
}
	
	

